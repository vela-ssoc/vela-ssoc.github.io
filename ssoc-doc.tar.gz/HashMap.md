# hashmap
独立于tab的map结构绑定

## rock.hm
- 生成hashmap
- hm = rock.hm()
### 默认接口
支持index和newIndex 方法
```lua
    local hm = rock.hm{key1="val1" , key2="val2"}
    hm.aa = "helo"
    hm.ii = 10
```